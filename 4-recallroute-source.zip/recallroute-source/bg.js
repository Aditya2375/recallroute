// Original local 3D ribbon renderer and landing interaction. No dependencies.
export function initTopo(unused,toggle){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const scene=document.getElementById('paper-scene'),canvas=document.getElementById('memory-loop'),ctx=canvas.getContext('2d');
 const card=document.getElementById('paper-stack'),flip=document.getElementById('demo-flip');
 let paused=reduced,first=true,visible=true,raf=0,last=0,time=0,x=0,y=0,tx=0,ty=0,w=0,h=0,dpr=1,turned=false;
 let workspace=document.body.classList.contains('workspace-mode');
 const TAU=Math.PI*2;
 function point(t,v=0){
   // A broad trefoil ribbon, not a stock particle background.
   const twist=t*1.5+.6;
   const nx=Math.cos(t)*.25*Math.cos(twist),ny=Math.sin(t)*.25*Math.cos(twist),nz=Math.sin(twist)*.25;
   return {x:Math.sin(t)+.52*Math.sin(2*t)+v*nx,y:Math.cos(t)-.52*Math.cos(2*t)+v*ny,z:.47*Math.sin(3*t)+v*nz};
 }
 function project(p,rot){
   const cy=Math.cos(rot),sy=Math.sin(rot),cx=Math.cos(-.21+y*.008),sx=Math.sin(-.21+y*.008);
   const xx=p.x*cy+p.z*sy,zz=-p.x*sy+p.z*cy,yy=p.y*cx-zz*sx,z=p.y*sx+zz*cx;
   const f=4.8/(4.8+z),scale=Math.min(w*.37,h*.32);
   return {x:w*.5+xx*scale*f,y:h*.48+yy*scale*f,z,scale:f};
 }
 function draw(){
  if(!ctx)return;ctx.clearRect(0,0,w,h);
  const rot=-.28+x*.009+Math.sin(time*.13)*.11;
  const faces=[];const n=220;
  for(let i=0;i<n;i++){
   const t=i/n*TAU,t2=(i+1)/n*TAU;
   const a=project(point(t,-1),rot),b=project(point(t,1),rot),c=project(point(t2,1),rot),d=project(point(t2,-1),rot);
   faces.push({pts:[a,b,c,d],z:(a.z+b.z+c.z+d.z)/4,t});
  }
  faces.sort((a,b)=>b.z-a.z);
  // Sparse technical registration grid behind the sculptural object.
  ctx.strokeStyle='#ffffff0b';ctx.lineWidth=.6;
  for(let i=1;i<7;i++){let xx=i*w/7;ctx.beginPath();ctx.moveTo(xx,30);ctx.lineTo(xx,h-35);ctx.stroke();}
  for(let i=1;i<7;i++){let yy=i*h/7;ctx.beginPath();ctx.moveTo(10,yy);ctx.lineTo(w-10,yy);ctx.stroke();}
  faces.forEach(f=>{
   const light=.47+.28*Math.sin(f.t*3+rot)+.18*Math.cos(f.t*2);
   const r=Math.round(124+130*light),g=Math.round(38+84*light),b=Math.round(10+42*light);
   ctx.beginPath();f.pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
   ctx.fillStyle=`rgb(${r} ${g} ${b})`;ctx.fill();ctx.strokeStyle=ctx.fillStyle;ctx.lineWidth=.8;ctx.stroke();
   ctx.beginPath();ctx.moveTo(f.pts[0].x,f.pts[0].y);ctx.lineTo(f.pts[3].x,f.pts[3].y);ctx.strokeStyle=`rgba(255,190,116,${.18+light*.3})`;ctx.lineWidth=.8;ctx.stroke();
  });
  // Three travelling beads turn the loop into a route.
  for(let i=0;i<3;i++){
   const t=time*.17+i*TAU/3,p=project(point(t,0),rot);
   ctx.beginPath();ctx.arc(p.x,p.y,4*p.scale,0,TAU);ctx.fillStyle='#fff2dc';ctx.shadowColor='#ff9d63';ctx.shadowBlur=12;ctx.fill();ctx.shadowBlur=0;
  }
 }
 function frame(ts){
  if(paused||!visible||workspace||document.hidden){raf=0;return;}
  const dt=last?Math.min((ts-last)/1000,.05):0;last=ts;time+=dt;
  x+=(tx-x)*.055;y+=(ty-y)*.055;
  if(!matchMedia('(max-width: 700px)').matches)card.style.transform=`translate(-50%,-50%) rotateX(${y*.13}deg) rotateY(${x*.13}deg) rotate(-7deg)`;
  draw();raf=requestAnimationFrame(frame);
 }
 function start(){if(!paused&&visible&&!workspace&&!document.hidden&&!raf){last=0;raf=requestAnimationFrame(frame);}}
 function stop(){cancelAnimationFrame(raf);raf=0;}
 function resize(){const r=scene.getBoundingClientRect();w=r.width;h=r.height;dpr=Math.min(devicePixelRatio||1,1.75);canvas.width=w*dpr;canvas.height=h*dpr;ctx?.setTransform(dpr,0,0,dpr,0,0);draw();}
 function state(){document.body.classList.toggle('motion-paused',paused);toggle.textContent=paused?(first&&reduced?'Motion off':'Resume motion'):'Pause motion';toggle.setAttribute('aria-pressed',String(paused));if(paused){stop();flip.getAnimations().forEach(a=>a.cancel());}else start();}
 scene.addEventListener('pointermove',e=>{if(paused||e.pointerType==='touch')return;const r=scene.getBoundingClientRect();tx=((e.clientX-r.left)/r.width-.5)*20;ty=((e.clientY-r.top)/r.height-.5)*20;});
 scene.addEventListener('pointerleave',()=>{tx=ty=0;});
 flip.addEventListener('click',()=>{
  turned=!turned;flip.setAttribute('aria-pressed',String(turned));flip.setAttribute('aria-label',turned?'Return to the example question':'Reveal the example answer');
  const q=document.getElementById('demo-question');q.replaceChildren();
  if(turned){q.append('The library',document.createElement('br'),'opens at ');const a=document.createElement('span');a.className='demo-answer';a.textContent='9 AM.';q.append(a);}
  else{q.append('The library',document.createElement('br'),'opens at ');const a=document.createElement('span');a.className='demo-blank';a.textContent='_____.';q.append(a);}
  document.getElementById('demo-hint').textContent=turned?'Exactly where your notes said.':'Think first. Then reveal.';
  card.classList.toggle('is-revealed',turned);
  if(!paused)q.animate([{opacity:.2,transform:'translateY(6px)'},{opacity:1,transform:'none'}],{duration:450,easing:'cubic-bezier(.22,1,.36,1)'});
 });
 const capture=()=>{document.getElementById('capture-workbench').scrollIntoView({behavior:paused?'instant':'smooth',block:'start'});document.getElementById('source').focus({preventScroll:true});};
 document.getElementById('start-capture').addEventListener('click',capture);document.getElementById('scroll-capture').addEventListener('click',capture);
 document.getElementById('hero-sample').addEventListener('click',()=>{document.getElementById('sample').click();document.getElementById('generate').click();});
 toggle.addEventListener('click',()=>{first=false;paused=!paused;state();});
 document.addEventListener('visibilitychange',()=>document.hidden?stop():start());
 if(ctx)new ResizeObserver(resize).observe(scene);
 new IntersectionObserver(es=>{visible=es[0].isIntersecting;if(visible)start();else stop();},{threshold:0}).observe(scene);
 const viewObserver=new MutationObserver(()=>{const next=document.body.classList.contains('workspace-mode');if(next===workspace)return;workspace=next;if(workspace){stop();}else{resize();start();}});viewObserver.observe(document.body,{attributes:true,attributeFilter:['class']});
 resize();state();
}
