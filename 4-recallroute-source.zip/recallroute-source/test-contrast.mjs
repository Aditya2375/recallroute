import {chromium} from 'playwright-core';
import {spawn} from 'node:child_process';
const s=spawn('python3',['-m','http.server','8795'],{cwd:import.meta.dirname});
const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});
const p=await b.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
await p.goto('http://localhost:8795/standalone.html');
async function check(view){
const r=await p.evaluate(()=>{
 function col(v){return (v.match(/[\d.]+/g)||[]).map(Number)}
 function lum(c){return c.slice(0,3).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0)}
 return [...document.querySelectorAll('body *')].filter(e=>e.getClientRects().length&&!e.disabled&&[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim())).map(e=>{
 const cs=getComputedStyle(e);let el=e,bg;
 while(el){bg=col(getComputedStyle(el).backgroundColor);if(bg.length===3||bg[3]===1)break;el=el.parentElement;}
 bg=bg?.length>=3?bg:[255,255,255];const ink=parseFloat(cs.webkitTextStrokeWidth)>0?cs.webkitTextStrokeColor:cs.color;const a=lum(col(ink)),bb=lum(bg),ratio=(Math.max(a,bb)+.05)/(Math.min(a,bb)+.05);const size=parseFloat(cs.fontSize);const large=size>=24||(size>=18.66&&parseFloat(cs.fontWeight)>=700);
 return {tag:e.tagName,cls:e.className,text:e.textContent.trim().slice(0,65),size,fg:cs.color,bg,ratio:+ratio.toFixed(2),fail:ratio<(large?3:4.5)};
 }).filter(x=>x.fail)
});console.log(view,JSON.stringify(r,null,2));return r.length;}
let fails=await check('capture');await p.click('#hero-sample');fails+=await check('practice');await p.click('[data-view="insights"]');fails+=await check('reflect');
await p.setViewportSize({width:320,height:780});await p.click('[data-view="notes"]');fails+=await check('capture-320');await p.click('#hero-sample');fails+=await check('practice-320');await p.click('[data-view="insights"]');fails+=await check('reflect-320');console.log('Failing text nodes:',fails);await b.close();s.kill();if(fails)process.exitCode=1;
