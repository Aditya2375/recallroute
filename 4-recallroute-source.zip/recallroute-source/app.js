import {SAMPLE,makeCards,nextCard,priority,metrics,makeAttempt,validateImport,historyCSV} from './core.js';
import {initTopo} from './bg.js';
const $=id=>document.getElementById(id);
let source='',cards=[],history=[],current=null,graded=false,routeDrawn=false;
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const finePointer=window.matchMedia('(pointer: fine)').matches;

function status(message,error=false){$('status').textContent=message;$('status').classList.toggle('error',error);}
function moveIndicator(){const active=document.querySelector('.steps button.active'),ind=$('steps-indicator');if(!active||!ind)return;ind.style.left=active.offsetLeft+'px';ind.style.width=active.offsetWidth+'px';}
function view(name){
  document.querySelectorAll('.view').forEach(v=>{const on=v.id===name+'-view';v.hidden=!on;v.classList.toggle('on',on);});
  document.querySelectorAll('.steps button').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  document.body.classList.toggle('workspace-mode',name!=='notes');
  moveIndicator();
  if(name==='practice')renderPractice();
  if(name==='insights')renderInsights();
  status('');
  window.scrollTo({top:0,behavior:'instant'});
}
function count(){$('char-count').textContent=$('source').value.length.toLocaleString()+' / 24,000 characters';}
function build(){
  try{
    const c=makeCards($('source').value);
    source=$('source').value;cards=c;history=[];current=nextCard(cards,history);graded=false;routeDrawn=false;
    $('card-count').textContent=cards.length;
    const pill=$('card-count');pill.classList.remove('pop');void pill.offsetWidth;pill.classList.add('pop');
    view('practice');renderPractice(true);
    status(`${cards.length} extractive cards ready. Check the source wording if a blank seems awkward.`);
  }catch(e){status(e.message,true);}
}

function renderPrompt(){
  const p=$('prompt');p.replaceChildren();
  const start=Number(current.id.split('-').at(-1));
  const before=current.evidence.slice(0,start),after=current.evidence.slice(start+current.answer.length);
  const blank=document.createElement('span');blank.className='blank'+(graded?' revealed':'');blank.textContent=graded?current.answer:'________';
  p.append(document.createTextNode(before),blank,document.createTextNode(after));
}

function renderPractice(reset=false){
  $('empty-practice').hidden=cards.length>0;
  $('practice-content').hidden=!cards.length;
  $('line-badge').hidden=!cards.length;
  if(!cards.length){renderRoute();return;}
  if(!current)current=nextCard(cards,history);
  if(!reset){renderQueue();renderRoute();return;}
  $('line-badge').textContent='Source line '+current.line;
  graded=false;
  renderPrompt();
  $('answer').value='';$('answer').disabled=false;
  $('confidence').value=50;$('confidence').disabled=false;setFill(50);$('confidence-value').textContent='50%';
  $('feedback').hidden=true;$('check').disabled=false;$('skip').disabled=false;
  graded=false;renderQueue();renderRoute();
}

function cardState(c){
  const past=history.filter(h=>h.cardId===c.id);
  if(!past.length)return{key:'none',label:'Not practiced',cls:''};
  const last=past.at(-1);
  if(last.correct)return{key:'recalled',label:'Reinforce later',cls:'st-ok'};
  if(last.confidence>=75)return{key:'confmiss',label:'High-confidence miss · revisit',cls:'st-confmiss'};
  return{key:'missed',label:'Missed · revisit',cls:'st-miss'};
}

function renderQueue(){
  const list=$('queue');list.replaceChildren();
  cards.slice().sort((a,b)=>priority(b,history)-priority(a,history)).slice(0,6).forEach(c=>{
    const li=document.createElement('li'),badge=document.createElement('span'),body=document.createElement('span'),small=document.createElement('small');
    badge.textContent='L'+c.line;
    body.textContent=c.prompt.length>68?c.prompt.slice(0,65)+'...':c.prompt;
    const st=cardState(c);small.textContent=st.label;if(st.cls)small.className=st.cls;
    body.append(small);li.append(badge,body);list.append(li);
  });
}

const SVGNS='http://www.w3.org/2000/svg';
function renderRoute(){
  const wrap=$('route-map');wrap.replaceChildren();
  if(!cards.length)return;
  const n=cards.length,H=150,pad=20;
  const W=Math.max(320,Math.round(n*26+2*pad));
  const pts=cards.map((c,i)=>{
    const x=n===1?W/2:pad+(W-2*pad)*(i/(n-1));
    const y=H/2+Math.sin(i*1.7+0.9)*30+Math.sin(i*0.53)*10;
    return{x,y,card:c};
  });
  const svg=document.createElementNS(SVGNS,'svg');
  svg.style.width=W+'px';
  svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.setAttribute('role','group');
  svg.setAttribute('aria-label','Practice route across your cards');
  let d=`M ${pts[0].x} ${pts[0].y}`;
  for(let i=1;i<pts.length;i++){
    const p0=pts[i-1],p1=pts[i],mx=(p0.x+p1.x)/2;
    d+=` C ${mx} ${p0.y}, ${mx} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  const path=document.createElementNS(SVGNS,'path');
  path.setAttribute('d',d);path.setAttribute('class','route-path');
  svg.append(path);
  pts.forEach((p,i)=>{
    const st=cardState(p.card);
    const g=document.createElementNS(SVGNS,'g');
    g.setAttribute('class','route-node '+st.key+(current&&p.card.id===current.id?' current':''));
    g.setAttribute('tabindex','0');g.setAttribute('role','button');
    g.setAttribute('aria-label',`Card from line ${p.card.line}, ${st.label.toLowerCase()}`);
    const title=document.createElementNS(SVGNS,'title');title.textContent=`Line ${p.card.line} · ${st.label}`;g.append(title);
    const hit=document.createElementNS(SVGNS,'circle');
    hit.setAttribute('class','hit');hit.setAttribute('cx',p.x);hit.setAttribute('cy',p.y);hit.setAttribute('r',14);
    const halo=document.createElementNS(SVGNS,'circle');
    halo.setAttribute('class','halo');halo.setAttribute('cx',p.x);halo.setAttribute('cy',p.y);halo.setAttribute('r',5);halo.style.transformOrigin=`${p.x}px ${p.y}px`;
    const dot=document.createElementNS(SVGNS,'circle');
    dot.setAttribute('class','dot');dot.setAttribute('cx',p.x);dot.setAttribute('cy',p.y);dot.setAttribute('r',5);
    const label=document.createElementNS(SVGNS,'text');
    label.setAttribute('x',p.x);label.setAttribute('y',p.y+18);label.textContent='L'+p.card.line;
    g.append(hit,halo,dot,label);
    const jump=()=>{if(current?.id===p.card.id){$(graded?'next':'answer').focus();return;}current=p.card;renderPractice(true);$('answer').focus();};
    g.addEventListener('click',jump);
    g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();jump();}});
    svg.append(g);
  });
  wrap.append(svg);
  const len=path.getTotalLength();
  if(!routeDrawn&&!reduced){
    path.style.strokeDasharray=len;path.style.strokeDashoffset=len;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{path.style.strokeDashoffset=0;}));
    routeDrawn=true;
  }
}

function grade(){
  if(!current||graded)return;
  if(!$('answer').value.trim()){status('Try an answer before checking, or skip this card.',true);$('answer').focus();return;}
  const attempt=makeAttempt(current,$('answer').value,$('confidence').value);
  history.push(attempt);graded=true;
  $('answer').disabled=true;$('confidence').disabled=true;$('check').disabled=true;$('skip').disabled=true;
  $('feedback').hidden=false;
  $('feedback').classList.toggle('miss',!attempt.correct);
  $('verdict').textContent=attempt.correct?'Matches your source.':'Not an exact match. Take another look.';
  $('expected').textContent=current.answer;
  $('evidence').textContent=`Line ${current.line}: ${current.evidence}`;
  $('reflection').textContent=attempt.correct
    ?(attempt.confidence<50?'You recalled it with low confidence. That is worth noticing.':'Your answer matched. Try retrieving it again later.')
    :(attempt.confidence>=75?'You felt quite sure, but the wording did not match. Recheck the source before carrying that confidence forward.':'A miss is information, not a grade. Compare your answer with the original text. A valid paraphrase may still be marked wrong.');
  renderPrompt();renderQueue();renderRoute();status('');
  $('next').focus({preventScroll:true});
  $('feedback').scrollIntoView({block:'nearest',behavior:'instant'});
}

function tween(el,target,suffix='',dash=false){
  if(el._tween)cancelAnimationFrame(el._tween);
  if(dash){el.textContent='—';return;}
  const dur=reduced?0:650,start=performance.now();
  function step(ts){
    const k=dur?Math.min(1,(ts-start)/dur):1,e=1-Math.pow(1-k,3);
    el.textContent=Math.round(target*e)+suffix;
    if(k<1)el._tween=requestAnimationFrame(step);
  }
  el._tween=requestAnimationFrame(step);
}

function renderInsights(){
  const m=metrics(history),has=history.length>0;
  tween($('stat-attempts'),m.attempts);
  tween($('stat-accuracy'),has?m.accuracy:0,'%',!has);
  tween($('stat-confidence'),has?m.confidence:0,'%',!has);
  tween($('stat-misses'),m.overconfidentErrors);
  requestAnimationFrame(()=>{
    $('accuracy-bar').style.width=m.accuracy+'%';
    $('confidence-bar').style.width=m.confidence+'%';
  });
  $('accuracy-label').textContent=Math.round(m.accuracy)+'%';
  $('confidence-label').textContent=Math.round(m.confidence)+'%';
  $('gap-text').textContent=!has?'Practice a card to see your first signal.'
    :Math.abs(m.gap)<10?'Your confidence is close to your exact-match recall in this small session.'
    :m.gap>0?`Average confidence is ${Math.round(m.gap)} percentage points above exact-match recall. Revisit misses before assuming mastery.`
    :`Exact-match recall is ${Math.round(-m.gap)} percentage points above confidence. You may know more than you feel you do.`;
  const body=$('history');body.replaceChildren();
  if(!has){
    const tr=document.createElement('tr'),td=document.createElement('td');
    td.colSpan=5;td.textContent='No attempts yet. Try a few cards, then return here.';
    tr.append(td);body.append(tr);
  }
  history.slice(-20).reverse().forEach(h=>{
    const c=cards.find(c=>c.id===h.cardId),tr=document.createElement('tr');
    [['Line '+c.line,''],[c.answer,''],[h.given,''],[h.correct?'MATCH':'MISS',h.correct?'ok':'no'],[h.confidence+'%','']].forEach(([s,cls])=>{
      const td=document.createElement('td');td.textContent=s;if(cls)td.className=cls;tr.append(td);
    });
    body.append(tr);
  });
}

function setFill(v){$('confidence').style.setProperty('--fill',v+'%');}
function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>view(b.dataset.view)));
$('source').addEventListener('input',count);
$('sample').addEventListener('click',()=>{if(cards.length&&!confirm('Replace notes and reset practice when you generate again?'))return;$('source').value=SAMPLE;count();status('Synthetic library-planning example loaded. These are invented practice notes, not a real event.');});
$('generate').addEventListener('click',()=>{if(history.length&&!confirm('Making cards again resets this session. Download your session first if needed. Continue?'))return;build();});
$('back-notes').addEventListener('click',()=>view('notes'));
$('confidence').addEventListener('input',()=>{setFill($('confidence').value);$('confidence-value').textContent=$('confidence').value+'%';});
$('check').addEventListener('click',grade);
$('answer').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();grade();}});
function advance(){current=nextCard(cards,history,current?.id);renderPractice(true);$('answer').focus();}
$('next').addEventListener('click',advance);
$('skip').addEventListener('click',advance);
$('export-session').addEventListener('click',()=>{if(!cards.length)return status('Make cards before downloading a session.',true);download('recallroute-session.json',JSON.stringify({version:1,source,history},null,2),'application/json');});
$('export-csv').addEventListener('click',()=>{if(!history.length)return status('Practice a card before exporting attempts.',true);download('recallroute-attempts.csv',historyCSV(history,cards),'text/csv');});
$('import').addEventListener('click',()=>$('import-file').click());
$('import-file').addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    if(file.size>2000000)throw new Error('Session files must be under 2 MB.');
    const data=validateImport(JSON.parse(await file.text()));
    if(history.length&&!confirm('Replace this session with the imported one?'))return;
    ({source,cards,history}=data);current=nextCard(cards,history);routeDrawn=false;
    $('source').value=source;count();$('card-count').textContent=cards.length;
    view('practice');renderPractice(true);status('Session restored. Imported answers were re-scored against the notes.');
  }catch(err){status(err.message,true);}
  finally{e.target.value='';}
});
$('clear').addEventListener('click',()=>{
  if(!confirm('Clear notes, cards and answers from this tab? Export first if you want a copy.'))return;
  source='';cards=[];history=[];current=null;$('source').value='';$('card-count').textContent='0';count();view('notes');
  status('Session cleared. No server copy exists.');
});

window.addEventListener('resize',moveIndicator);
initTopo($('topo'),$('motion-toggle'));
count();
moveIndicator();
