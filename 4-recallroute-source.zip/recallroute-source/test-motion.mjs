import {chromium} from 'playwright-core';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const server=spawn('python3',['-m','http.server','8793'],{cwd:import.meta.dirname});
const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});
try{
 const p=await b.newPage({viewport:{width:320,height:780}});
 await p.goto('http://localhost:8793/standalone.html');
 assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await p.locator('#demo-flip').focus();await p.keyboard.press('Enter');
 assert.equal(await p.getAttribute('#demo-flip','aria-pressed'),'true');
 assert.match(await p.textContent('#demo-question'),/9 AM/);
 await p.keyboard.press('Enter');assert.match(await p.textContent('#demo-question'),/_____/);
 await p.click('#motion-toggle');
 assert.equal(await p.getAttribute('#motion-toggle','aria-pressed'),'true');
 await p.locator('#memory-loop').scrollIntoViewIfNeeded();
 await p.waitForTimeout(150);
 const before=await p.locator('#memory-loop').evaluate(c=>c.toDataURL());await p.waitForTimeout(180);
 const after=await p.locator('#memory-loop').evaluate(c=>c.toDataURL());assert.equal(before,after,'canvas renderer stops when paused');
 await p.screenshot({path:'/tmp/shots/10-notes-320.png',fullPage:true});
 await p.click('#start-capture');assert.equal(await p.evaluate(()=>document.activeElement.id),'source');
 assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await p.screenshot({path:'/tmp/shots/12-workbench-mobile.png',fullPage:true});
 const q=await b.newPage({viewport:{width:1440,height:1000}});await q.goto('http://localhost:8793/standalone.html');
 await q.locator('#capture-workbench').scrollIntoViewIfNeeded();await q.screenshot({path:'/tmp/shots/13-workbench-desktop.png'});
 await q.click('#hero-sample');assert.equal(await q.locator('#practice-view').isVisible(),true);
 assert.equal(await q.textContent('#card-count'),'7');
 console.log('MOTION UI OK: 320px entry, keyboard reveal, canvas actually pauses, editor CTA focus, example-route entry');
}finally{await b.close();server.kill();}
