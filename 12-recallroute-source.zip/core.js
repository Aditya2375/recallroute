export const MAX_SOURCE = 24000;
export const SAMPLE = `Community library pilot\nThe library pilot opens on Saturday at 9 AM.\nVolunteers will sort 60 donated books before opening.\nThe quiet reading room has 12 seats.\nBorrowers may keep a book for 14 days.\nThe repair desk checks damaged covers before books return to the shelf.\nThe pilot ends with a feedback circle at 4 PM.\nThe next planning meeting takes place on Tuesday.`;
const STOP = new Set('the a an and or but in on at to of for with is are was were be been this that it its as by from will may has have before after then than into'.split(' '));
export function splitSource(text) {
  if (typeof text !== 'string' || !text.trim()) throw new Error('Add a few lines of notes first.');
  if (text.length > MAX_SOURCE) throw new Error(`Keep notes under ${MAX_SOURCE.toLocaleString()} characters.`);
  return text.split(/\n+/).map(s => s.trim()).filter(Boolean).map((s,i)=>({line:i+1,text:s}));
}
export function makeCards(text) {
  const rows=splitSource(text), cards=[];
  rows.forEach(row=>{
    if(row.text.length<25 || row.text.length>650) return;
    const number=row.text.match(/\b\d+(?:\.\d+)?(?:\s+(?:AM|PM|days?|seats?|books?|hours?|minutes?))?\b/i);
    const words=Array.from(row.text.matchAll(/\b[A-Za-z][A-Za-z'-]{4,}\b/g));
    const pick=number || words.filter(w=>!STOP.has(w[0].toLowerCase())).sort((a,b)=>b[0].length-a[0].length)[0];
    if(!pick) return;
    const start=pick.index, answer=pick[0];
    cards.push({id:`l${row.line}-${start}`,line:row.line,prompt:row.text.slice(0,start)+'______'+row.text.slice(start+answer.length),answer,evidence:row.text});
  });
  if(!cards.length) throw new Error('Use full sentences with facts or terms, one per line. No cards could be made from these notes.');
  return cards.slice(0,40);
}
export function normalize(s) {return String(s).normalize('NFKC').trim().toLowerCase().replace(/[.,;:!?]+$/g,'').replace(/\s+/g,' ');}
export function checkAnswer(given, expected) {return normalize(given)===normalize(expected);}
export function priority(card,history) {
  const h=history.filter(x=>x.cardId===card.id);
  if(!h.length) return 85;
  const last=h.at(-1);
  if(!last.correct) return 100 + last.confidence/10;
  return Math.max(0,60-last.confidence/2-h.filter(x=>x.correct).length*5);
}
export function nextCard(cards,history,excludeId) {
  const candidates=cards.filter(c=>c.id!==excludeId);
  return (candidates.length?candidates:cards).map((card,i)=>({card,i,p:priority(card,history)})).sort((a,b)=>b.p-a.p||a.i-b.i)[0]?.card||null;
}
export function metrics(history) {
  const n=history.length,correct=history.filter(h=>h.correct).length;
  const mean=n?history.reduce((s,h)=>s+h.confidence,0)/n:0;
  const accuracy=n?correct/n*100:0;
  return {attempts:n,correct,accuracy,confidence:mean,gap:mean-accuracy,overconfidentErrors:history.filter(h=>!h.correct&&h.confidence>=75).length};
}
export function makeAttempt(card,given,confidence,ts=Date.now()) {
  const value=Number(confidence);
  if(!Number.isFinite(value)||value<0||value>100) throw new Error('Confidence must be between 0 and 100.');
  return {cardId:card.id,given:String(given).slice(0,1000),confidence:value,correct:checkAnswer(given,card.answer),ts};
}
export function validateImport(data) {
  if(!data || data.version!==1 || typeof data.source!=='string') throw new Error('Choose a RecallRoute v1 session JSON file.');
  const cards=makeCards(data.source), ids=new Set(cards.map(c=>c.id));
  if(!Array.isArray(data.history)||data.history.length>10000) throw new Error('Invalid or oversized practice history.');
  const history=data.history.map(h=>{
    if(!h||!ids.has(h.cardId)||typeof h.correct!=='boolean'||typeof h.given!=='string'||h.given.length>1000||!Number.isFinite(h.confidence)||h.confidence<0||h.confidence>100||!Number.isFinite(h.ts)) throw new Error('Invalid practice attempt in session.');
    const c=cards.find(c=>c.id===h.cardId);
    return {...makeAttempt(c,h.given,h.confidence,h.ts)};
  });
  return {source:data.source,cards,history};
}
export function csvEscape(value) {let s=String(value);if(/^[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
export function historyCSV(history,cards) {
  const rows=[['Source line','Answer','Your answer','Correct','Confidence %','Time UTC']];
  history.forEach(h=>{const c=cards.find(c=>c.id===h.cardId);if(c)rows.push([c.line,c.answer,h.given,h.correct,h.confidence,new Date(h.ts).toISOString()]);});
  return rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');
}
